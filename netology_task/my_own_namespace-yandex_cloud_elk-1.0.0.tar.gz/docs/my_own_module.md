# Module my_own_module
This module can be create file with content.

## Version
version_added: "1.0.0"

## Module parameters
* path:  
    description: Name of the file to be created.  
    required: true  
    type: str  
* content:  
    description: Contents in the target file  
    required: true  
    type: str  

extends_documentation_fragment: []

## Author Information
Andrey Shitov