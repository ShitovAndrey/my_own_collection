Role Name
=========

This role is testing the my_own_module module.


Role Variables
--------------
|       Параметр      | Тип    | Значение по умолчанию   | Описание                     |
|---------------------|--------|-------------------------|------------------------------|
| path                | string | /tmp/my_own_module.txt  | Определяет путь к файлу.     |
| content             | string | Hello Netology!         | Определяет содержимое файла. |

Author Information
------------------

Andrey Shitov
