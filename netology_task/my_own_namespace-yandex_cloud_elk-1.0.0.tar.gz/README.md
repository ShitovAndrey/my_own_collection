# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.

## Modules
* my_own_module - This module maybe create file with content.

## Roles
* create_file_with_content - This role is testing the my_own_module module.

## Author Information
Andrey Shitov